def create_player(player_id=None, name="Juan Pujol Garcia", current_chapter=1,
                   current_objective="I need to do something.",
                   german_trust=20, german_suspicion=10,
                   network_credibility=30, allied_confidence=10):
    return {
        "player_id": player_id,
        "name": name,
        "current_chapter": current_chapter,
        "current_objective": current_objective,
        "german_trust": german_trust,
        "german_suspicion": german_suspicion,
        "network_credibility": network_credibility,
        "allied_confidence": allied_confidence,
        "agents": [],
        "reports": [],
        "thoughts_log": [],
        "lives": 7,
        "decisions": [],
        "puzzles_solved": 0,
        "puzzles_failed": 0,
        "ending": None
    }


def clamp(value):
    return max(0, min(100, value))


def increase_trust(player, amount):
    player["german_trust"] = clamp(player["german_trust"] + amount)


def decrease_trust(player, amount):
    player["german_trust"] = clamp(player["german_trust"] - amount)


def increase_suspicion(player, amount):
    player["german_suspicion"] = clamp(player["german_suspicion"] + amount)


def decrease_suspicion(player, amount):
    player["german_suspicion"] = clamp(player["german_suspicion"] - amount)


def increase_credibility(player, amount):
    player["network_credibility"] = clamp(player["network_credibility"] + amount)


def decrease_credibility(player, amount):
    player["network_credibility"] = clamp(player["network_credibility"] - amount)


def increase_allied_confidence(player, amount):
    player["allied_confidence"] = clamp(player["allied_confidence"] + amount)


def decrease_allied_confidence(player, amount):
    player["allied_confidence"] = clamp(player["allied_confidence"] - amount)


def apply_signed_trust(player, amount):
    if amount >= 0:
        increase_trust(player, amount)
    else:
        decrease_trust(player, abs(amount))


def apply_signed_suspicion(player, amount):
    if amount >= 0:
        increase_suspicion(player, amount)
    else:
        decrease_suspicion(player, abs(amount))


def apply_signed_credibility(player, amount):
    if amount >= 0:
        increase_credibility(player, amount)
    else:
        decrease_credibility(player, abs(amount))


def apply_signed_confidence(player, amount):
    if amount >= 0:
        increase_allied_confidence(player, amount)
    else:
        decrease_allied_confidence(player, abs(amount))


def is_exposed(player):
    return player["german_suspicion"] >= 95


def has_lost_trust(player):
    return player["german_trust"] <= 5


def add_thought(player, thought):
    player["thoughts_log"].append(thought)


def set_objective(player, text):
    player["current_objective"] = text








def create_agent(agent_id=None, name="", occupation="", location="",
                  cover_story="", reliability=50, status="ACTIVE"):
    return {
        "agent_id": agent_id,
        "name": name,
        "occupation": occupation,
        "location": location,
        "cover_story": cover_story,
        "reliability": reliability,
        "status": status,
        "report_history": [],
        "known_relationships": []
    }


def agent_add_report_record(agent, location_used, chapter):
    agent["report_history"].append({"location": location_used, "chapter": chapter})


def agent_last_known_location(agent):
    if agent["report_history"]:
        return agent["report_history"][-1]["location"]
    return agent["location"]


def agent_check_consistency(agent, new_location):
    return new_location == agent_last_known_location(agent)


def agent_display(agent):
    return (f"AGENT: {agent['name']}\n"
            f"Occupation: {agent['occupation']}\n"
            f"Location: {agent['location']}\n"
            f"Status: {agent['status']}\n"
            f"Reports filed: {len(agent['report_history'])}")









def create_report(report_id=None, agent=None, chapter=0, report_type="",
                   content="", consistency_score=0, quality_score=0,
                   risk_level="LOW", trust_change=0, suspicion_change=0,
                   credibility_change=0):
    return {
        "report_id": report_id,
        "agent": agent,
        "chapter": chapter,
        "report_type": report_type,
        "content": content,
        "consistency_score": consistency_score,
        "quality_score": quality_score,
        "risk_level": risk_level,
        "trust_change": trust_change,
        "suspicion_change": suspicion_change,
        "credibility_change": credibility_change
    }


def report_summary(report):
    agent_name = report["agent"]["name"] if report["agent"] else "N/A"
    return f"[Ch.{report['chapter']}] {report['report_type']} via {agent_name} | Risk:{report['risk_level']}"














def create_historical_character(character_id=None, name="", role="", connection="",
                                 significance="", unlocked=False):
    return {"character_id": character_id, "name": name, "role": role,
            "connection": connection, "significance": significance, "unlocked": unlocked}


def unlock_character(character):
    character["unlocked"] = True


def character_display(character):
    return ("CHARACTER FILE\n"
            f"NAME: {character['name']}\n"
            f"ROLE: {character['role']}\n"
            f"CONNECTION TO GARBO: {character['connection']}\n"
            f"HISTORICAL SIGNIFICANCE: {character['significance']}")






def create_statistics():
    return {
        "total_reports_sent": 0,
        "successful_reports": 0,
        "failed_reports": 0,
        "agents_created": 0,
        "chapters_completed": 0
    }


def stats_record_report(stats, success):
    stats["total_reports_sent"] += 1
    if success:
        stats["successful_reports"] += 1
    else:
        stats["failed_reports"] += 1


def stats_record_agent_created(stats):
    stats["agents_created"] += 1


def stats_record_chapter_completed(stats):
    stats["chapters_completed"] += 1



