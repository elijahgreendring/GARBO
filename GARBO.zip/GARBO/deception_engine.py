MAX_SWING = 10


def bound_value(value):
    return max(-MAX_SWING, min(MAX_SWING, value))


def analyze_report(agent, clue_reliability, network_credibility,
                    current_suspicion, is_consistent, historical_context_bonus=0):

    consistency_score = 85 if is_consistent else 35

    quality_score = (0.4 * clue_reliability +
                      0.3 * agent["reliability"] +
                      0.3 * network_credibility)
    quality_score = round(quality_score)

    if not is_consistent:
        quality_score -= 25

    quality_score += historical_context_bonus
    quality_score = max(0, min(100, quality_score))

    if consistency_score < 40 or current_suspicion > 70:
        risk_level = "HIGH"
    elif consistency_score < 70 or current_suspicion > 40:
        risk_level = "MEDIUM"
    else:
        risk_level = "LOW"

    trust_change = round(quality_score / 20)
    if risk_level == "HIGH":
        trust_change = max(0, trust_change - 3)
    elif risk_level == "MEDIUM":
        trust_change = max(0, trust_change - 1)
    trust_change = bound_value(trust_change)

    if is_consistent and quality_score >= 60:
        suspicion_change = -round(quality_score / 25)
    else:
        suspicion_change = round((100 - consistency_score) / 12)
    suspicion_change = bound_value(suspicion_change)

    if is_consistent:
        credibility_change = round(quality_score / 25)
    else:
        credibility_change = -round((100 - consistency_score) / 10)
    credibility_change = bound_value(credibility_change)

    return {
        "consistency_score": consistency_score,
        "quality_score": quality_score,
        "risk_level": risk_level,
        "trust_change": trust_change,
        "suspicion_change": suspicion_change,
        "credibility_change": credibility_change
    }

