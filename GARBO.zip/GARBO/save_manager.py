import pickle



ACTIVITY_LOG_FILE = "garbo_activity_log.txt"




_log_entry_counter = 0


def save_game(state_dict, filename):
    try:
        with open(filename, "wb") as f:
            pickle.dump(state_dict, f)
        return True
    except:
        return False


def load_game(filename):
    try:
        with open(filename, "rb") as f:
            data = pickle.load(f)
        return data
    except:
        return None


def log_event(event_type, description, log_file=ACTIVITY_LOG_FILE):
    global _log_entry_counter
    try:
        _log_entry_counter += 1
        with open(log_file, "a") as f:
            f.write(f"[Entry {_log_entry_counter}] {event_type}: {description}\n")
    except:
        pass

