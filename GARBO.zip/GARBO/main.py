from game import start_game


def main():
    try:
        start_game()
    except:
        print("\nGame interrupted. Goodbye.")


if __name__ == "__main__":
    main()
