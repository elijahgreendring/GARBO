CLUE_TYPES = {
    "1": {
        "name": "Railway observation",
        "reliability": 70
    },
    "2": {
        "name": "Shipping information",
        "reliability": 65
    },
    "3": {
        "name": "Newspaper information",
        "reliability": 50
    },
    "4": {
        "name": "Public military information",
        "reliability": 60
    }
}


TIMELINE = [
    ("1936-1939",
     "Spanish Civil War influences Juan's opposition to totalitarianism. [FACT]"),

    ("1939",
     "World War II begins and Juan decides to work against Nazi Germany. [FACT]"),

    ("1941",
     "The British reject Juan's offer, so he finds a way to get recruited by German intelligence. [FACT]"),

    ("1941-42",
     "Juan works from Lisbon and creates reports pretending to come from Britain. [FACT]"),

    ("1942",
     "British intelligence takes control of GARBO's case. [FACT]"),

    ("1943",
     "GARBO's network and radio messages become more important. [FACT]"),

    ("January 1944",
     "German intelligence asks GARBO for information about the coming invasion. [FACT]"),

    ("1944",
     "Operation Fortitude uses GARBO and the imaginary FUSAG to support the Pas-de-Calais deception. [FACT]"),

    ("6 June 1944",
     "D-Day begins with the Allied landings in Normandy. [FACT]"),

    ("9 June 1944",
     "GARBO sends an important message suggesting that Normandy is only a diversion. [FACT]"),

    ("29 July 1944",
     "GARBO is told that Hitler has awarded him the Iron Cross. [FACT]")
]


HISTORICAL_CHARACTERS_DATA = [
    {
        "name": "Juan Pujol Garcia",
        "role": "Double agent (codename GARBO)",
        "connection": "The player character.",
        "significance":
            "A Spanish double agent whose imaginary network became important to the Allied deception."
    },

    {
        "name": "Tomas Harris",
        "role": "MI5 case officer",
        "connection": "GARBO's handler and collaborator.",
        "significance":
            "Worked with Pujol to manage the fictional network and its reports."
    },

    {
        "name": "Adolf Hitler",
        "role": "German Head of State",
        "connection":
            "Part of the German leadership affected by the deception.",
        "significance":
            "German leaders continued to expect a major attack at Pas-de-Calais after D-Day."
    },

    {
        "name": "Winston Churchill",
        "role": "British Prime Minister",
        "connection":
            "Senior Allied leader who received information about the success of the deception.",
        "significance":
            "Was informed about the German response to the Calais deception."
    },

    {
        "name": "George S. Patton",
        "role": "US General",
        "connection": "Public figurehead of the fictional FUSAG army.",
        "significance":
            "His reputation helped make the imaginary army believable to German intelligence."
    }
]


CHAPTERS = [
    {
        "number": 1,
        "title": "THE MAN WHO WOULD NOT WAIT",
        "objective": "Find a way to serve Britain after being rejected.",

        "beats": [

            {
                "type": "narrative",
                "lines": [
                    "SPAIN — MEMORY",
                    "Juan has seen political extremism from close range.",
                    "He wants to act against Nazi Germany, but he is not a trained spy.",
                    "He approaches British representatives but is rejected.",
                    "The door closes, so Juan decides to find another way."
                ]
            },

            {
                "type": "choice",
                "correct_option": "2",
                "prompt": "What does Juan do after the British refusal?",

                "options": {
                    "1": (
                        "Abandon the idea and return to ordinary life.",
                        {"confidence": -3}
                    ),

                    "2": (
                        "Find a way to make the Germans recruit him first.",
                        {"confidence": 2}
                    ),

                    "3": (
                        "Keep trying to reach British intelligence through another route.",
                        {"confidence": 1}
                    )
                }
            },

            {
                "type": "narrative",
                "lines": [
                    "MADRID — 1941",
                    "The German service is easier for Juan to approach.",
                    "He pretends to be sympathetic to Germany and says that he wants to work in Britain.",
                    "The Germans see an opportunity, while Juan sees a chance to enter the war."
                ]
            },

            {
                "type": "puzzle",
                "puzzle_id": "cover_identity"
            },

            {
                "type": "thought",
                "text":
                    "They think I am offering myself to Germany.\n"
                    "In reality, I am trying to enter the war from the other side."
            }
        ]
    },


    {
        "number": 2,
        "title": "THE MAN WHO NEVER REACHED BRITAIN",
        "objective": "Build a believable British existence from Lisbon.",

        "beats": [

            {
                "type": "narrative",
                "lines": [
                    "LISBON — 1941",
                    "Juan does not actually reach Britain as promised.",
                    "Instead, he works from Lisbon using books, maps, newspapers and public information.",
                    "He starts creating a fictional network of agents.",
                    "Each imaginary person needs a background, location and reason for knowing information."
                ]
            },

            {
                "type": "report_mission",
                "chapter_context":
                    "A German controller wants the first report from Britain."
            },

            {
                "type": "puzzle",
                "puzzle_id": "network_memory"
            },

            {
                "type": "narrative",
                "lines": [
                    "The first reports are not very dramatic.",
                    "That makes them more believable because real intelligence can contain ordinary information.",
                    "Berlin continues to listen."
                ]
            },

            {
                "type": "thought",
                "text":
                    "A lie this large cannot depend on one brilliant story.\n"
                    "It has to survive hundreds of ordinary details."
            }
        ]
    },


    {
        "number": 3,
        "title": "GARBO",
        "objective":
            "Turn the invented reports into a trusted intelligence network.",

        "beats": [

            {
                "type": "narrative",
                "lines": [
                    "LONDON — 1942",
                    "British intelligence understands what Juan has been doing.",
                    "Tomás Harris becomes his handler.",
                    "The British side wants the information to remain consistent and believable."
                ]
            },

            {
                "type": "choice",
                "correct_option": "1",
                "prompt":
                    "HARRIS asks what the network must protect above everything else.",

                "options": {
                    "1": (
                        "Consistency between reports.",
                        {"credibility": 4, "confidence": 2}
                    ),

                    "2": (
                        "Making every report dramatic.",
                        {"credibility": -2, "suspicion": 1}
                    ),

                    "3": (
                        "Sending as much information as possible, even if some is uncertain.",
                        {"credibility": 1, "confidence": 1}
                    )
                }
            },

            {
                "type": "puzzle",
                "puzzle_id": "message_filter"
            },

            {
                "type": "narrative",
                "lines": [
                    "GERMAN INTELLIGENCE",
                    "The German reaction changes slowly from curiosity to dependence.",
                    "They begin asking GARBO for information they cannot easily get elsewhere.",
                    "GARBO is becoming a trusted source of information about Britain."
                ]
            },

            {
                "type": "thought",
                "text":
                    "The dangerous moment is not when they believe the first lie.\n"
                    "It is when they start asking the lie questions."
            }
        ]
    }
]

