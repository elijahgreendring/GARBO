import mysql.connector as db

def db_connect():
    global con
    try:
        con = db.connect(
            host="localhost",
            user="root",
            password="password",
            database="garbo_game"
        )
        return True
    except:
        print(f"Database connection failed: ")
        con = None
        return False

def db_isconnected():
    return con is not None

def db_execute(query, params=None, fetch=False):
    global con

    if not db_isconnected():
        print("Database not connected.")
        return None

    mycur = None

    try:
        mycur = con.cursor()
        mycur.execute(query, params or ())

        if fetch:
            result = mycur.fetchall()
            mycur.close()
            return result

        con.commit()
        mycur.close()
        return True

    except:
        print(f"Database error: ")

        if con:
            con.rollback()

        if mycur:
            mycur.close()

        return None

def insert_player(name, chapter, objective, trust, suspicion, credibility, confidence):
    query = ("INSERT INTO players (player_name, current_chapter, current_objective, "
              "german_trust, german_suspicion, network_credibility, allied_confidence, "
              "created_date, lives) VALUES (%s,%s,%s,%s,%s,%s,%s,CURDATE(),7)")
    return db_execute(query, (name, chapter, objective, trust, suspicion, credibility, confidence))


def update_player(player_id, chapter, objective, trust, suspicion, credibility, confidence, lives=7, ending_type=None, ending_name=None):
    query = ("UPDATE players SET current_chapter=%s, current_objective=%s, german_trust=%s, "
              "german_suspicion=%s, network_credibility=%s, allied_confidence=%s, lives=%s, "
              "ending_type=%s, ending_name=%s WHERE player_id=%s")
    return db_execute(query, (chapter, objective, trust, suspicion, credibility, confidence,
                              lives, ending_type, ending_name, player_id))


def get_agents(player_id):
    return db_execute("SELECT * FROM agents WHERE player_id=%s", (player_id,), fetch=True)


def insert_report(player_id, agent_id, chapter, report_type, content,
                   consistency, quality, risk, trust_change, suspicion_change, credibility_change):
    query = ("INSERT INTO reports (player_id, agent_id, chapter_number, report_type, content, "
              "consistency_score, quality_score, risk_level, trust_change, suspicion_change, "
              "credibility_change, date_sent) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,CURDATE())")
    return db_execute(query, (player_id, agent_id, chapter, report_type, content,
                               consistency, quality, risk, trust_change,
                               suspicion_change, credibility_change))


def get_reports(player_id):
    query = "SELECT * FROM reports WHERE player_id=%s ORDER BY report_id"
    return db_execute(query, (player_id,), fetch=True)


def log_event_db(player_id, event_type, description):
    query = ("INSERT INTO game_events (player_id, event_type, event_description, event_date) "
              "VALUES (%s,%s,%s,CURDATE())")
    return db_execute(query, (player_id, event_type, description))


def insert_statistics(player_id):
    return db_execute("INSERT INTO player_statistics (player_id) VALUES (%s)", (player_id,))


def get_riddles(chapter_number):
    query = ("SELECT riddle_id, question, correct_answer, difficulty "
             "FROM riddles WHERE chapter_number=%s ORDER BY riddle_id")
    return db_execute(query, (chapter_number,), fetch=True)


def achievement_exists(player_id, ending_type):
    query = ("SELECT achievement_id FROM achievements "
             "WHERE player_id=%s AND ending_type=%s")
    rows = db_execute(query, (player_id, ending_type), fetch=True)
    return bool(rows)


def save_achievement(player_id, ending_type, ending_name, description):
    query = ("INSERT INTO achievements "
             "(player_id, ending_type, ending_name, description, unlocked_date) "
             "VALUES (%s,%s,%s,%s,CURDATE())")
    return db_execute(query, (player_id, ending_type, ending_name, description))


def get_achievements(player_id):
    query = ("SELECT achievement_id, ending_type, ending_name, description, unlocked_date "
             "FROM achievements WHERE player_id=%s ORDER BY achievement_id")
    return db_execute(query, (player_id,), fetch=True)
