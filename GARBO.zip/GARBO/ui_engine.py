def clear_screen():
    print("\n\n" + ("~" * 120) + "\n\n")


def print_header(title):
    line = "=" * 120
    print(line)
    print(title.center(120))
    print(line)



def print_separator():
    print("-" * 120)


def print_menu(options):
    for key in options:
        print(f"[{key}] {options[key]}")
    print_separator()


def print_status_panel(player):
    chapter = player["current_chapter"]
    print(f"CHAPTER {chapter}  |  NEXT: {player['current_objective']}  |  LIVES: {player.get('lives', 7)}")

    if chapter <= 2:
        german = "BERLIN: GARBO is useful, but needs to ensure trust."
        allied = "BRITISH INTELLIGENCE: Pujol is not yet inside the operation."

        
    elif chapter == 3:
        german = "GERMAN INTELLIGENCE: GARBO has been accepted as a promising source."
        allied = "BRITISH INTELLIGENCE: Harris is beginning to see the value of the deception."

        
    elif chapter == 4:
        german = "BERLIN: GARBO's network is really good to replace."
        allied = "MI5: Harris is protecting the continuity of the story behind every report."

        
    elif chapter == 5:
        german = "GERMAN HIGH COMMAND: GARBO's reporting is being used to reinforce the Calais picture."
        allied = "MI5: Confidence is high, but every new report must fit the whole network."

        
    else:
        german = "BERLIN: GARBO is now trusted enough by Germans."
        allied = "ALLIED COMMAND: The deception must survive even after Normandy is attacked."

        

    if player["german_suspicion"] >= 70:
        german = "BERLIN: GARBO is really suspecious."

        
    elif player["german_trust"] <= 25:
        german = "GERMAN INTELLIGENCE: GARBO lost trust by Germans."

        

    if player["network_credibility"] <= 30:
        allied = "MI5: Harris is worried in GARBO's deception."

        
    elif player["allied_confidence"] >= 60:
        allied = "MI5: Harris is highly confident in GARBO's deception."

        

    print(german)
    print(allied)
    print_separator()


def print_thought(thought_text):
    print_separator()
    print("JUAN'S THOUGHTS")
    print()
    print(thought_text)
    print_separator()


def print_lines(lines):
    for line in lines:
        print(line)
    print()


def get_validated_choice(prompt, valid_choices):
    while True:
        try:
            choice = input(prompt).strip()
        except:
            print("\nInvalid choice. Please enter a valid option.")
            continue
        if choice in valid_choices:
            return choice
        print("Invalid input. Please choose one of the listed options.")


def get_text_input(prompt):
    try:
        return input(prompt).strip()
    except:
        return ""


def get_validated_int(prompt, min_val, max_val):
    while True:
        raw = get_text_input(prompt)
        try:
            value = int(raw)
            if min_val <= value <= max_val:
                return value
            print(f"Please enter a number between {min_val} and {max_val}.")
        except:
            print("Invalid input. Please enter a whole number.")


def pause():
    get_text_input("\nPress ENTER to continue...")


def print_report_analysis(report):
    print_header("REPORT ASSESSMENT")
    if report["risk_level"] == "HIGH":
        print("The story has dangerous weaknesses. Berlin may ask questions.")

        
    elif report["risk_level"] == "MEDIUM":
        print("The story is plausible, but it needs to fit the wider network.")

        
    else:
        print("The story holds together. It sounds like information from a real source.")

        
    print("The important thing is not one report — it is whether every report still makes sense together.")
    print_separator()


def print_puzzle_result(success, message):
    print_separator()
    if success:
        print("PUZZLE SOLVED")
    else:
        print("PUZZLE RESULT")
    print(message)
    print_separator()


def print_game_over(reason):
    print_header("THE DECEPTION HAS FAILED")
    print(reason)
    print()
    print("The historical outcome is not being rewritten.")
    print("This is the player's gameplay failure.")
    print_separator()
