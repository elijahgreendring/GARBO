import random
from data_models import *
from ui_engine import *
from deception_engine import *
from database_manager import *
from game_data import *
from save_manager import *

DEFAULT_SAVE_FILE = "garbo_save.dat"

player = None
stats = create_statistics()
characters = [
    create_historical_character(
        name=c["name"], role=c["role"], connection=c["connection"],
        significance=c["significance"], unlocked=(c["name"] == "Juan Pujol Garcia")
    )
    for c in HISTORICAL_CHARACTERS_DATA
]
db_ready = False
running = True
game_over = False

def show_chapter_intro(chapter):
    clear_screen()
    width = 120
    title = chapter["title"]
    number = chapter["number"]
    locations = {
        1: "SPAIN — 1941", 2: "LISBON — 1941", 3: "LONDON — 1942",
        4: "EUROPE — 1943", 5: "EUROPE — 1944", 6: "NORMANDY — JUNE 1944"
    }
    descriptions = {
        1: "Britain has rejected Juan's offer. The door is closed, so he must find another way into the war.",
        2: "Juan is supposed to be in Britain. He is not. From Lisbon, he must build a British existence on paper.",
        3: "British intelligence now understands the value of GARBO. The invented network must survive German scrutiny.",
        4: "GARBO's reports are becoming part of a much larger intelligence picture. Every detail must remain coherent.",
        5: "The deception is reaching its most dangerous stage. German expectations are beginning to depend on GARBO.",
        6: "The Allied invasion has begun, but the deception is not finished. GARBO's final task is underway."
    }
    print("=" * width)
    print((f"CHAPTER {number}").center(width))
    print((title).center(width))
    print("=" * width)
    print("\n" * 2)
    print((chapter["objective"]).center(width))
    print("\n")
    print((locations.get(number, "EUROPE")).center(width))
    print("\n")
    text = descriptions.get(number, "The next stage of GARBO's operation begins.")
    for line in text.split("."):
        line = line.strip()
        if line:
            print(line.center(width))
    print("\n" * 2)
    print("[N] BEGIN    [M] MENU    [X] STOP".center(width))
    print("-" * width)
    while True:
        choice = get_validated_choice("Enter choice: ", ["N", "M", "X"])
        if choice == "N":
            return "begin"
        if choice == "M":
            return "menu"
        return "stop"

def start_game():
    global db_ready
    clear_screen()
    print("=" * 120)
    print("=" * 120)
    print()
    print("G A R B O".center(120))
    print()
    print("T H E   L A S T   G R E A T".center(120))
    print()
    print("D E C E P T I O N".center(120))
    print()
    print("=" * 120)
    print("=" * 120)
    print()
    print("[N] CONTINUE".center(120))
    get_validated_choice("Enter choice: ", ["N"])

    db_ready = db_connect()
    clear_screen()
    print_header("OPERATION GARBO — MISSION BRIEFING")
    print_lines([
        "You are Juan Pujol Garcia, operating under the codename GARBO.",
        "",
        "OBJECTIVE",
        "Help Britain by building and maintaining a convincing deception",
        "against German intelligence. Survive long enough for the deception",
        "to contribute to the Allied plan.",
        "",
        "YOUR GAME RULES",
        "• You begin with 7 lives. Serious mistakes can cost a life.",
        "• Keep German trust high and German suspicion low.",
        "• Protect the credibility of your fictional agent network.",
        "• Maintain Allied confidence in your operation.",
        "• Choices, reports and puzzles can change the state of the operation.",
        "• Your decisions affect the ending you can achieve.",
        "",
        "NAVIGATION",
        "N = Next scene    P = Previous scene    S = Save",
        "M = Main menu     X = Stop game",
        "",
        "THE INTELLIGENCE DESK",
        "From the main menu, the Intelligence Desk contains the current",
        "objective, agent network, intelligence reports and character files.",
        "",
        "MI5 is Britain's security and intelligence service. Tomás Harris",
        "is GARBO's handler and helps manage the deception operation.",
        "",
        "The numbers shown for lives and status are part of the gameplay.",
        "Use them to understand the condition of the operation."
    ])
    print_separator()
    print("[N] BEGIN OPERATION" )
    print("[X] EXIT")
    choice = get_validated_choice("Enter choice: ", ["N", "X"])
    if choice == "X":
        return
    main_menu()

def new_game():
    global player, game_over
    game_over = False
    player = create_player()
    player["lives"] = 7
    player["ending"] = None
    player["current_beat"] = 0
    player["chapter_intro_seen"] = False
    player["completed_beats"] = []
    if db_ready:
        new_id = insert_player(player["name"], player["current_chapter"],
                               player["current_objective"], player["german_trust"],
                               player["german_suspicion"], player["network_credibility"],
                               player["allied_confidence"])
        if new_id:
            player["player_id"] = new_id
            insert_statistics(new_id)
    seed_agents()
    log_event("GAME STARTED", "New six-chapter game initiated.")

def seed_agents():
    starter_agents = [
        ("THOMAS", "Dock Worker", "Liverpool", "Sympathetic Welsh nationalist", 65),
        ("CARLOS", "Government Clerk", "London", "Disillusioned civil servant", 55),
    ]
    for name, occ, loc, cover, rel in starter_agents:
        agent = create_agent(name=name, occupation=occ, location=loc,
                             cover_story=cover, reliability=rel)
        player["agents"].append(agent)
        stats_record_agent_created(stats)

def main_menu():
    global running, game_over
    while running:
        clear_screen()
        if player is None:
            print_header("GARBO: THE LAST GREAT DECEPTION")
            choice = get_validated_choice(
                "[1] New Game  [2] Load Game  [0] Exit\n> ",
                ["1", "2", "0"]
            )
            if choice == "1":
                new_game()
                run_chapter()
            elif choice == "2":
                load_saved_game()
                if player is not None:
                    run_chapter()
            else:
                running = False
            continue

        print_status_panel(player)
        print_menu({
            "1": "Intelligence Desk",
            "2": "Historical Timeline",
            "3": "Achievements",
            "4": "Database Manager"
        })
        print("[M] Return To Chapter")
        print_separator()
        choice = get_validated_choice(
            "Enter choice: ", ["1", "2", "3", "4", "M"]
        )
        if choice == "1":
            intelligence_desk()
        elif choice == "2":
            show_timeline()
        elif choice == "3":
            show_achievements()
        elif choice == "4":
            database_menu()
        else:
            run_chapter()

        if game_over:
            handle_game_over_choice()

def run_chapter():
    global game_over, running

    while running and not game_over:
        if player["current_chapter"] > len(CHAPTERS):
            clear_screen()
            print_header("EPILOGUE — THE DECEPTION'S LEGACY")
            print_lines([
                "Juan Pujol Garcia did not win the war alone.",
                "GARBO was one part of a larger Allied deception system.",
                "Its purpose was to keep German attention away from the true invasion plan."
            ])
            pause()
            return

        chapter = CHAPTERS[player["current_chapter"] - 1]
        set_objective(player, chapter["objective"])

        if not player.get("chapter_intro_seen", False):
            result = show_chapter_intro(chapter)
            if result == "menu":
                return
            if result == "stop":
                running = False
                return
            player["chapter_intro_seen"] = True

        beats = chapter["beats"]
        beat_index = max(0, min(player.get("current_beat", 0), len(beats) - 1))

        while running and not game_over:
            player["current_beat"] = beat_index
            beat = beats[beat_index]
            clear_screen()
            print_header(f"CHAPTER {chapter['number']} | {chapter['title']}")
            print(f"SCENE {beat_index + 1} OF {len(beats)}")
            print_separator()

            interactive = beat["type"] in {"choice", "report_mission", "puzzle"}
            already_done = beat_index in player.get("completed_beats", [])

            if beat["type"] == "narrative":
                print_lines(beat["lines"])
            elif beat["type"] == "thought":
                add_thought(player, beat["text"])
                print_thought(beat["text"])
            elif interactive and already_done:
                print_lines([
                    "This scene has already been completed.",
                    "Your previous action remains part of the operation.",
                    "Use NEXT to continue or PREV to review an earlier scene."
                ])
            elif beat["type"] == "choice":
                if not run_choice_beat(beat):
                    return
                player.setdefault("completed_beats", []).append(beat_index)
            elif beat["type"] == "report_mission":
                if run_report_mission(chapter["number"], beat.get("chapter_context", "")) is False:
                    return
                player.setdefault("completed_beats", []).append(beat_index)
            elif beat["type"] == "puzzle":
                if not run_puzzle(beat["puzzle_id"], chapter["number"]):
                    return
                player.setdefault("completed_beats", []).append(beat_index)

            if game_over:
                return

            print()
            print_separator()
            if beat_index == 0:
                print("[N] NEXT     [S] SAVE")
            else:
                print("[N] NEXT     [P] PREV     [S] SAVE")
            print("[M] MENU     [X] STOP")
            print_separator()

            choices = ["N", "S", "M", "X"]
            if beat_index > 0:
                choices.insert(1, "P")
            choice = get_validated_choice("Enter choice: ", choices)

            if choice == "N":
                if beat_index < len(beats) - 1:
                    beat_index += 1
                else:
                    stats_record_chapter_completed(stats)
                    log_event("CHAPTER COMPLETED", chapter["title"])
                    player["current_chapter"] += 1
                    player["current_beat"] = 0
                    player["chapter_intro_seen"] = False
                    player["completed_beats"] = []
                    break
            elif choice == "P":
                beat_index -= 1
            elif choice == "S":
                player["current_beat"] = beat_index
                save_current_game(pause_after=False)
            elif choice == "M":
                player["current_beat"] = beat_index
                return
            elif choice == "X":
                running = False
                return

def run_choice_beat(beat):
    print_separator()
    print(beat["prompt"])
    keys = list(beat["options"].keys())
    for key in keys:
        print(f"[{key}] {beat['options'][key][0]}")
    choice = get_validated_choice("Enter choice: ", keys)
    _, effects = beat["options"][choice]
    player.setdefault("decisions", []).append(choice)
    if beat.get("correct_option") and choice != beat["correct_option"]:
        if not lose_life("That decision weakened the operation."):
            return False
    apply_effects(effects)
    return not game_over

def apply_effects(effects):
    if "trust" in effects:
        apply_signed_trust(player, effects["trust"])
    if "suspicion" in effects:
        apply_signed_suspicion(player, effects["suspicion"])
    if "credibility" in effects:
        apply_signed_credibility(player, effects["credibility"])
    if "confidence" in effects:
        apply_signed_confidence(player, effects["confidence"])
    check_failure()

def lose_life(reason):
    global game_over
    player["lives"] = max(0, player.get("lives", 7) - 1)
    print_separator()
    print(f"LIFE LOST — {reason}")
    print(f"LIVES REMAINING: {player['lives']}")
    print_separator()
    if player["lives"] <= 0:
        game_over = True
        print_game_over("YOU LOST! GARBO's operation has failed after seven lost lives.")
        pause()
        return False
    return True

def run_puzzle(puzzle_id, chapter_number=None):
    clear_screen()
    print_header("LOGIC RIDDLE")
    if not db_ready:
        print_lines([
            "Riddles require the MySQL database connection.",
            "Please reconnect to the database before continuing."
        ])
        return True
    if chapter_number is None:
        chapter_number = player["current_chapter"]
    rows = get_riddles(chapter_number)
    if not rows:
        print_lines(["No riddle is configured for this chapter."])
        return True
    _, question, correct_answer, difficulty = rows[0]
    print(f"DIFFICULTY: {difficulty}")
    print_separator()
    print_lines(question.split("\n"))
    while True:
        raw = get_text_input("Enter your integer answer: ")
        try:
            value = int(raw)
            break
        except ValueError:
            print("Please enter an integer.")
    if value == correct_answer:
        player["puzzles_solved"] = player.get("puzzles_solved", 0) + 1
        print_puzzle_result(True, "Correct. Your reasoning holds.")
        return True
    player["puzzles_failed"] = player.get("puzzles_failed", 0) + 1
    if not lose_life("The riddle answer was incorrect."):
        return False
    print_puzzle_result(False, "Incorrect. One life has been lost.")
    return True

def run_report_mission(chapter_number, context_text):
    active_agents = [a for a in player["agents"] if a["status"] == "ACTIVE"]
    if not active_agents:
        print_lines(["No active agents available. Creating an emergency contact."])
        emergency = create_agent(name="MANUEL", occupation="Waiter", location="Lisbon",
                                  cover_story="Contact of convenience", reliability=40)
        player["agents"].append(emergency)
        active_agents = [emergency]

    clear_screen()
    print_header("INTELLIGENCE REPORT")
    if context_text:
        print_lines([context_text])

    print("SELECT INFORMATION:")
    for k, v in CLUE_TYPES.items():
        print(f"[{k}] {v['name']}")
    clue_choice = get_validated_choice("Choose a clue: ", list(CLUE_TYPES.keys()))
    clue = CLUE_TYPES[clue_choice]

    print("\nSELECT AGENT:")
    for i, agent in enumerate(active_agents, start=1):
        print(f"[{i}] {agent['name']} ({agent['occupation']}, last at {agent_last_known_location(agent)})")
    agent_choice = get_validated_int("Choose agent number: ", 1, len(active_agents))
    agent = active_agents[agent_choice - 1]

    location_used = get_text_input(
        f"Report location (last used: {agent_last_known_location(agent)}): ")
    is_consistent = agent_check_consistency(agent, location_used)

    result = analyze_report(
        agent, clue["reliability"], player["network_credibility"],
        player["german_suspicion"], is_consistent
    )

    preview_report = create_report(agent=agent, chapter=chapter_number,
                                   report_type=clue["name"],
                                   consistency_score=result["consistency_score"],
                                   quality_score=result["quality_score"],
                                   risk_level=result["risk_level"],
                                   credibility_change=result["credibility_change"])
    print_report_analysis(preview_report)

    confirm = get_validated_choice("[1] Send  [2] Cancel\n> ", ["1", "2"])
    if confirm == "2":
        print_lines(["Report cancelled. No message leaves the desk."])
        return

    agent_add_report_record(agent, location_used, chapter_number)
    report = create_report(agent=agent, chapter=chapter_number,
                           report_type=clue["name"], content=location_used,
                           consistency_score=result["consistency_score"],
                           quality_score=result["quality_score"],
                           risk_level=result["risk_level"],
                           trust_change=result["trust_change"],
                           suspicion_change=result["suspicion_change"],
                           credibility_change=result["credibility_change"])
    player["reports"].append(report)

    apply_signed_trust(player, result["trust_change"])
    apply_signed_suspicion(player, result["suspicion_change"])
    apply_signed_credibility(player, result["credibility_change"])
    stats_record_report(stats, success=is_consistent)

    if db_ready and player.get("player_id"):
        insert_report(player["player_id"], agent.get("agent_id"), chapter_number,
                      clue["name"], location_used, result["consistency_score"],
                      result["quality_score"], result["risk_level"],
                      result["trust_change"], result["suspicion_change"],
                      result["credibility_change"])
        log_event_db(player["player_id"], "REPORT SENT", f"{agent['name']} - {clue['name']}")

    log_event("REPORT TRANSMITTED", f"{agent['name']} | consistent={is_consistent} | {result}")
    print_header("REPORT TRANSMITTED")
    check_failure()
    return not game_over

def check_failure():
    global game_over
    if is_exposed(player):
        game_over = True
        print_game_over("German suspicion has become critically high. GARBO has been exposed.")
    elif has_lost_trust(player):
        game_over = True
        print_game_over("German intelligence no longer considers GARBO reliable.")
    elif player["current_chapter"] >= 6 and player["network_credibility"] < 20:
        game_over = True
        print_game_over("The network lacks the credibility needed for the final deception.")

def load_achievements():
    if db_ready and player and player.get("player_id"):
        rows = get_achievements(player["player_id"])
        return rows if rows else []
    return []

def store_achievement(ending_type, ending_name, description):
    if not db_ready or not player.get("player_id"):
        return False

    if achievement_exists(player["player_id"], ending_type):
        return False

    return bool(save_achievement(
        player["player_id"], ending_type, ending_name, description
    ))

def determine_ending():
    trust = player["german_trust"]
    suspicion = player["german_suspicion"]
    credibility = player["network_credibility"]
    confidence = player["allied_confidence"]
    puzzles = player.get("puzzles_solved", 0)
    decisions = player.get("decisions", [])

    if puzzles >= 5 and len(decisions) >= 2 and decisions[0] == "2" and decisions[-1] == "1" and suspicion <= 35:
        return "GOOD_SECRET", "THE PERFECT SHADOW", (
            "GARBO survives the deception without allowing either side to see the whole picture.\n"
            "The network remains convincing, the final message holds, and the false Calais picture survives its most dangerous test.\n"
            "This is the secret ending: the player managed both the human side of the operation and the logic holding the deception together."
        )

    if trust >= 65 and credibility >= 65 and confidence >= 55 and suspicion < 65:
        return "GOOD_HARD", "THE DECEPTION HOLDS", (
            "The German leadership continues to believe the Calais story while Allied confidence in GARBO remains strong.\n"
            "The deception buys the Allies the time they need. It is a difficult victory because almost every part of the network had to remain coherent."
        )

    if trust >= 50 and credibility >= 45 and confidence >= 35 and suspicion < 80:
        return "GOOD_EASY", "THE MISSION SUCCEEDS", (
            "GARBO's deception survives long enough to contribute to the Allied plan.\n"
            "Not every decision was perfect, but the essential story remained believable when it mattered most."
        )

    if suspicion >= 90 or trust <= 10:
        return "BAD_EASY", "THE COVER COLLAPSES", (
            "German intelligence loses confidence in GARBO.\n"
            "A contradiction becomes too difficult to explain, and the operation ends before the final deception can succeed."
        )

    if credibility < 20 or confidence < 15:
        return "BAD_HARD", "THE NETWORK UNRAVELS", (
            "No single mistake destroys GARBO. Instead, too many small weaknesses accumulate.\n"
            "The fictional network can no longer support the story the Allies need Germany to believe."
        )

    return "BAD_SECRET", "THE SILENT FAILURE", (
        "GARBO is never completely exposed, yet the deception fails to achieve its decisive purpose.\n"
        "The operation disappears into uncertainty: trusted enough to continue, but not trusted enough to change the German picture.\n"
        "This is the secret bad ending."
    )

def finish_game():
    global game_over
    code, title, text = determine_ending()
    player["ending"] = code
    player["ending_name"] = title
    player["ending_type"] = code

    achievement_description = text.replace("\n", " ")
    stored = store_achievement(code, title, achievement_description)

    if db_ready and player.get("player_id"):
        update_player(
            player["player_id"], player["current_chapter"],
            player["current_objective"], player["german_trust"],
            player["german_suspicion"], player["network_credibility"],
            player["allied_confidence"], player.get("lives", 7),
            code, title
        )

    clear_screen()
    print_header("ENDING UNLOCKED")
    print(title)
    print_separator()
    print_lines(text.split("\n"))
    print_separator()
    if stored:
        print(f"ACHIEVEMENT STORED: {code} — {title}")
    else:
        print(f"ACHIEVEMENT: {code} — {title}")
    print()
    print("The historical outcome is not being rewritten; this is the player's path through the game.")
    pause()
    game_over = True

def show_achievements():
    clear_screen()
    print_header("ACHIEVEMENTS")

    if not db_ready or not player.get("player_id"):
        print_lines(["Achievements require a database-linked game."])
        pause()
        return

    achievements = load_achievements()
    if not achievements:
        print_lines([
            "No endings unlocked yet.",
            "Complete the story to earn an ending achievement."
        ])
        pause()
        return

    for achievement in achievements:
        print(f"[UNLOCKED] {achievement[2]}")
        print(f"TYPE: {achievement[1]}")
        print(f"{achievement[3]}")
        print(f"UNLOCKED: {achievement[4]}")
        print_separator()
    pause()

def handle_game_over_choice():
    global game_over, player, running
    if player.get("ending"):
        print_header("THE STORY IS COMPLETE")
        print_menu({"1": "View Achievements", "2": "Restart From The Beginning", "3": "Return To Main Menu", "0": "Exit"})
        choice = get_validated_choice("Enter choice: ", ["1", "2", "3", "0"])
        if choice == "1":
            show_achievements()
            game_over = False
        elif choice == "2":
            new_game()
            game_over = False
        elif choice == "3":
            player = None
            game_over = False
        else:
            running = False
        return

    print_menu({"1": "Restart From The Beginning", "2": "Return To Main Menu", "0": "Exit"})
    choice = get_validated_choice("Enter choice: ", ["1", "2", "0"])
    if choice == "1":
        new_game()
        game_over = False
    elif choice == "2":
        player = None
        game_over = False
    else:
        running = False

def intelligence_desk():
    if player["current_chapter"] >= 3:
        unlock_character(characters[1])
        unlock_character(characters[3])
    if player["current_chapter"] >= 5:
        unlock_character(characters[2])
        unlock_character(characters[4])

    clear_screen()
    print_header("INTELLIGENCE DESK")
    print_status_panel(player)
    print_header("CURRENT OBJECTIVE")
    print(player["current_objective"])
    print_separator()
    print_header("AGENT NETWORK")
    if player["agents"]:
        for agent in player["agents"]:
            print(agent_display(agent))
            print_separator()
    else:
        print("No agents recorded.")
    print_header("INTELLIGENCE REPORTS")
    if player["reports"]:
        recent = player["reports"][-5:]
        for report in recent:
            print(report_summary(report))
        earlier = len(player["reports"]) - len(recent)
        if earlier > 0:
            print(f"+ {earlier} earlier report(s) on file.")
    else:
        print("No reports filed yet.")
    print_separator()
    print_header("CHARACTER FILES")
    for character in characters:
        if character["unlocked"]:
            print(character_display(character))
        else:
            print("??? — Locked")
        print_separator()
    print("[M] BACK TO GAME MENU")
    get_validated_choice("Enter choice: ", ["M"])

def show_timeline():
    clear_screen()
    print_header("HISTORICAL TIMELINE")
    for year, event in TIMELINE:
        print(f"{year}: {event}")
    pause()

def save_current_game(pause_after=True):
    state = {
        "name": player["name"],
        "current_chapter": player["current_chapter"],
        "current_beat": player.get("current_beat", 0),
        "current_objective": player["current_objective"],
        "german_trust": player["german_trust"],
        "german_suspicion": player["german_suspicion"],
        "network_credibility": player["network_credibility"],
        "allied_confidence": player["allied_confidence"],
        "lives": player.get("lives", 7),
        "decisions": list(player.get("decisions", [])),
        "puzzles_solved": player.get("puzzles_solved", 0),
        "puzzles_failed": player.get("puzzles_failed", 0),
        "ending": player.get("ending"),
        "ending_type": player.get("ending_type"),
        "ending_name": player.get("ending_name"),
        "completed_beats": list(player.get("completed_beats", [])),
        "player_id": player.get("player_id"),
        "agents": [
            (a["name"], a["occupation"], a["location"], a["cover_story"],
             a["reliability"], a["status"], a["report_history"])
            for a in player["agents"]
        ],
        "stats": dict(stats)
    }
    if db_ready and player.get("player_id"):
        update_player(
            player["player_id"], player["current_chapter"], player["current_objective"],
            player["german_trust"], player["german_suspicion"],
            player["network_credibility"], player["allied_confidence"],
            player.get("lives", 7), player.get("ending_type"), player.get("ending_name")
        )
    ok = save_game(state, DEFAULT_SAVE_FILE)
    print_lines(["Game saved." if ok else "Save failed."])
    if ok:
        log_event("SAVE COMPLETED", DEFAULT_SAVE_FILE)
    if pause_after:
        pause()
    return ok

def load_saved_game():
    global player, stats
    state = load_game(DEFAULT_SAVE_FILE)
    if state is None:
        print_lines(["No valid save file found."])
        pause()
        return
    player = create_player(
        name=state["name"], current_chapter=state["current_chapter"],
        current_objective=state["current_objective"],
        german_trust=state["german_trust"], german_suspicion=state["german_suspicion"],
        network_credibility=state["network_credibility"],
        allied_confidence=state["allied_confidence"]
    )
    player["lives"] = state.get("lives", 7)
    player["decisions"] = list(state.get("decisions", []))
    player["puzzles_solved"] = state.get("puzzles_solved", 0)
    player["puzzles_failed"] = state.get("puzzles_failed", 0)
    player["ending"] = state.get("ending")
    player["ending_type"] = state.get("ending_type")
    player["ending_name"] = state.get("ending_name")
    player["current_beat"] = state.get("current_beat", 0)
    player["chapter_intro_seen"] = False
    player["completed_beats"] = list(state.get("completed_beats", []))
    player["player_id"] = state.get("player_id")
    for name, occ, loc, cover, rel, status, history in state["agents"]:
        agent = create_agent(name=name, occupation=occ, location=loc,
                             cover_story=cover, reliability=rel, status=status)
        agent["report_history"] = history
        player["agents"].append(agent)
    for key, val in state["stats"].items():
        stats[key] = val
    print_lines(["Game loaded."])
    pause()

def database_menu():
    while True:
        clear_screen()
        print_header("DATABASE MANAGER")
        if not db_ready:
            print("Database is not connected this session.")
            pause()
            return
        options = {"1": "View Agents in Database", "2": "View Reports in Database", "0": "Back"}
        print_menu(options)
        choice = get_validated_choice("Enter choice: ", list(options.keys()))
        if choice == "1":
            db_view_agents()
        elif choice == "2":
            db_view_reports()
        else:
            break

def db_view_agents():
    rows = get_agents(player["player_id"]) if player.get("player_id") else None
    clear_screen()
    print_header("AGENTS (DATABASE)")
    if rows:
        for row in rows:
            print(row)
    else:
        print("No records found.")
    pause()

def db_view_reports():
    rows = get_reports(player["player_id"]) if player.get("player_id") else None
    clear_screen()
    print_header("REPORTS (DATABASE)")
    if rows:
        for row in rows:
            print(row)
    else:
        print("No records found.")
    pause()
